package org.bukkit;
import java.util.Collection;import org.bukkit.entity.Player;import org.bukkit.plugin.PluginManager;
public class Bukkit{public static Collection<? extends Player> getOnlinePlayers(){return null;}public static PluginManager getPluginManager(){return null;}}
