package org.bukkit.command;
public interface CommandExecutor{boolean onCommand(CommandSender sender,Command cmd,String label,String[] args);}
