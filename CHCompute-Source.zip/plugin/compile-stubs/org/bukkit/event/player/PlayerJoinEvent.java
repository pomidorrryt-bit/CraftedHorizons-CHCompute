package org.bukkit.event.player;
import org.bukkit.entity.Player;
public abstract class PlayerJoinEvent{public abstract Player getPlayer();}
