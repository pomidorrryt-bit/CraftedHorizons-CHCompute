package org.bukkit.event.player;
import org.bukkit.entity.Player;
public abstract class PlayerQuitEvent{public abstract Player getPlayer();}
