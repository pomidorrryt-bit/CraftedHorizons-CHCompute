package org.bukkit.configuration.file;
public abstract class FileConfiguration {public abstract int getInt(String k,int def);public abstract boolean getBoolean(String k,boolean def);public abstract String getString(String k,String def);}
