package org.bukkit.plugin.java;
import java.io.File;import java.util.logging.Logger;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.FileConfiguration;
public abstract class JavaPlugin {public void onEnable(){}public void onDisable(){}public void saveDefaultConfig(){}public File getDataFolder(){return null;}public Logger getLogger(){return null;}public PluginCommand getCommand(String s){return null;}public FileConfiguration getConfig(){return null;}}
