#!/bin/sh
# Compile Java plugin with local API stubs. Stub classes are NOT packaged.
set -eu
cd "$(dirname "$0")"
mkdir -p build/stubs build/plugin
javac -encoding UTF-8 -d build/stubs $(find compile-stubs -name '*.java')
javac --release 21 -encoding UTF-8 -cp build/stubs -d build/plugin $(find src/main/java -name '*.java')
(cd build/plugin && jar cf ../../CHCompute-Paper-1.21.jar .)
(cd src/main/resources && jar uf ../../../CHCompute-Paper-1.21.jar plugin.yml config.yml)
echo "Built CHCompute-Paper-1.21.jar"
