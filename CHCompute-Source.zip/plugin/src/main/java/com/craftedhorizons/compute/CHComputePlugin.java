package com.craftedhorizons.compute;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpsConfigurator;
import com.sun.net.httpserver.HttpsParameters;
import com.sun.net.httpserver.HttpsServer;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;
import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.security.cert.Certificate;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * CH Compute: volunteer-only, TLS-pinned, non-authoritative offload queue.
 * No game ticks, inventories, combat or other authoritative calculations are delegated.
 */
public final class CHComputePlugin extends JavaPlugin implements Listener, CommandExecutor {
    private static final String PROTOCOL = "chcompute/1";
    private static final String ALGORITHM = "ch-height-v1";
    private static final int TILE_SIZE = 128;
    private static final char[] CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789".toCharArray();
    private final SecureRandom random = new SecureRandom();
    private final Set<UUID> online = ConcurrentHashMap.newKeySet();
    private final Map<String, PairCode> pendingPair = new ConcurrentHashMap<>();
    private final Map<UUID,String> credentials = new ConcurrentHashMap<>();
    private final Map<String,RateLimit> pairRate = new ConcurrentHashMap<>();
    private final Queue<Tile> todo = new ArrayDeque<>();
    private final Map<String,Lease> active = new HashMap<>();
    private final AtomicLong completed = new AtomicLong();
    private final Object queueMutex = new Object();
    private final Object credentialsMutex = new Object();
    private HttpsServer server;
    private ExecutorService webThreads;
    private String fingerprint = "";
    private boolean httpsEnabled = false;
    private int port;

    @Override public void onEnable() {
        saveDefaultConfig();
        if (!getDataFolder().isDirectory() && !getDataFolder().mkdirs()) {getLogger().severe("Cannot create data directory");return;}
        for(Player p : Bukkit.getOnlinePlayers()) online.add(p.getUniqueId());
        Bukkit.getPluginManager().registerEvents(this,this);
        if(getCommand("chcompute")!=null)getCommand("chcompute").setExecutor(this);
        loadCredentials();
        port=getConfig().getInt("https.port",18083);
        if (!getConfig().getBoolean("https.enabled",false)) {
            getLogger().info("CH Compute installed, HTTPS endpoint is OFF until a private keystore and an allocated port are configured.");
            return;
        }
        try{startHttps();}catch(Exception ex){
            getLogger().severe("CH Compute HTTPS disabled: "+ex.getClass().getSimpleName()+": "+ex.getMessage());
            getLogger().severe("The Minecraft server continues normally; fix keystore/port before enabling volunteer work.");
        }
    }
    @Override public void onDisable() {
        if(server!=null)server.stop(1);
        if(webThreads!=null)webThreads.shutdownNow();
        online.clear(); pendingPair.clear();
        synchronized(queueMutex){todo.clear();active.clear();}
    }
    @EventHandler public void join(PlayerJoinEvent event){online.add(event.getPlayer().getUniqueId());}
    @EventHandler public void quit(PlayerQuitEvent event){
        UUID uid=event.getPlayer().getUniqueId();online.remove(uid);
        pendingPair.entrySet().removeIf(e->e.getValue().user.equals(uid));
    }

    @Override public boolean onCommand(CommandSender sender,Command cmd,String label,String[] args){
        if(args.length==0 || args[0].equalsIgnoreCase("help")){
            sender.sendMessage("§bCH Compute §7| /chcompute pair | revoke | status | info | queue <1..20> (admin)");return true;
        }
        String action=args[0].toLowerCase(Locale.ROOT);
        if(action.equals("pair")){
            if(!(sender instanceof Player p)){sender.sendMessage("§cUse this in Minecraft as a player.");return true;}
            if(!p.hasPermission("chcompute.use")){sender.sendMessage("§cNo permission.");return true;}
            if(!httpsEnabled){sender.sendMessage("§cCH Compute server endpoint is not configured yet. Contact the server owner.");return true;}
            pendingPair.entrySet().removeIf(e->e.getValue().user.equals(p.getUniqueId()));
            String code=randomCode(10);
            pendingPair.put(code,new PairCode(p.getUniqueId(),System.currentTimeMillis()+10*60*1000L));
            p.sendMessage("§bCH Compute§f: open the Windows app and enter pairing code §e"+code);
            p.sendMessage("§7Expires in 10 minutes; do not share it. Volunteering is OFF by default.");
            p.sendMessage("§7Server: §f"+getConfig().getString("https.public-address","(ask admin)"));
            p.sendMessage("§7Certificate SHA-256: §f"+fingerprint);
            return true;
        }
        if(action.equals("revoke")){
            if(!(sender instanceof Player p)){sender.sendMessage("§cUse this in Minecraft.");return true;}
            credentials.remove(p.getUniqueId());
            pendingPair.entrySet().removeIf(e->e.getValue().user.equals(p.getUniqueId()));
            persistCredentials();p.sendMessage("§aCH Compute access revoked. The app can no longer request tasks.");return true;
        }
        if(action.equals("status")){
            sender.sendMessage("§bCH Compute§f: HTTPS "+(httpsEnabled?"§aON":"§cOFF")+"§f; pending="+pendingSize()+"; active="+activeSize()+"; completed="+completed.get());
            if(sender instanceof Player p) sender.sendMessage("§7Your connection: "+(credentials.containsKey(p.getUniqueId())?"paired":"not paired"));
            return true;
        }
        if(!sender.hasPermission("chcompute.admin")){sender.sendMessage("§cOnly server administrators may use this command.");return true;}
        if(action.equals("info")){
            sender.sendMessage("§bCH Compute | TLS port §f"+port+" | endpoint="+httpsEnabled);
            sender.sendMessage("§7Public address: §f"+getConfig().getString("https.public-address","not configured"));
            sender.sendMessage("§7Cert SHA-256: §f"+fingerprint);
            sender.sendMessage("§7Only auxiliary terrain-preview tiles are delegated, not Minecraft game ticks.");return true;
        }
        if(action.equals("queue")){
            if(args.length<2){sender.sendMessage("§cUsage: /chcompute queue <1..20>");return true;}
            int amount;try{amount=Integer.parseInt(args[1]);}catch(NumberFormatException ex){sender.sendMessage("§cEnter an integer.");return true;}
            if(amount<1||amount>20){sender.sendMessage("§cAllowed range: 1–20");return true;}
            int created=0;
            synchronized(queueMutex){
                while(created<amount && todo.size()+active.size()<100){
                    String id=UUID.randomUUID().toString();long seed=random.nextLong();
                    int x=(random.nextInt(256)-128)*128,z=(random.nextInt(256)-128)*128;
                    todo.offer(new Tile(id,seed,x,z));created++;
                }
            }
            sender.sendMessage("§aQueued "+created+" auxiliary terrain-preview jobs (not world changes).");return true;
        }
        sender.sendMessage("§cUnknown CH Compute subcommand. /chcompute help");return true;
    }
    private int pendingSize(){synchronized(queueMutex){return todo.size();}}
    private int activeSize(){synchronized(queueMutex){return active.size();}}
    private String randomCode(int count){StringBuilder s=new StringBuilder(count);for(int i=0;i<count;i++)s.append(CODE_CHARS[random.nextInt(CODE_CHARS.length)]);return s.toString();}

    private void startHttps() throws Exception {
        String fileName=getConfig().getString("https.keystore","server.p12");
        String pass=getConfig().getString("https.keystore-password","");
        if(pass.length()<12)throw new IllegalStateException("keystore-password missing or too short");
        if(fileName.contains("..")||fileName.contains("/")||fileName.contains("\\"))throw new IllegalStateException("keystore must be a file in CHCompute folder");
        File file=new File(getDataFolder(),fileName);
        if(!file.isFile())throw new FileNotFoundException("keystore not found at "+file.getAbsolutePath());
        KeyStore ks=KeyStore.getInstance("PKCS12");
        try(InputStream in=new FileInputStream(file)){ks.load(in,pass.toCharArray());}
        String alias=ks.aliases().nextElement();
        Certificate cert=ks.getCertificate(alias);
        if(cert==null)throw new IllegalStateException("TLS certificate missing");
        fingerprint=hex(sha256(cert.getEncoded()));
        KeyManagerFactory kmf=KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());kmf.init(ks,pass.toCharArray());
        SSLContext ssl=SSLContext.getInstance("TLS");ssl.init(kmf.getKeyManagers(),null,random);
        String bind=getConfig().getString("https.bind","0.0.0.0");
        if(port<1024||port>65535)throw new IllegalStateException("HTTPS port must be 1024–65535");
        server=HttpsServer.create(new InetSocketAddress(bind,port),8);
        server.setHttpsConfigurator(new HttpsConfigurator(ssl){
            @Override public void configure(HttpsParameters p){
                SSLParameters params=getSSLContext().getDefaultSSLParameters();
                params.setProtocols(new String[]{"TLSv1.3","TLSv1.2"});
                p.setSSLParameters(params);
            }
        });
        server.createContext("/v1/info",this::info);
        server.createContext("/v1/pair",this::pair);
        server.createContext("/v1/task",this::getTask);
        server.createContext("/v1/result",this::postResult);
        webThreads=Executors.newFixedThreadPool(4,r->{Thread t=new Thread(r,"CHCompute-HTTPS");t.setDaemon(true);return t;});
        server.setExecutor(webThreads);server.start();httpsEnabled=true;
        getLogger().info("HTTPS listening on "+bind+":"+port+" | cert SHA-256 "+fingerprint);
        getLogger().info("Only authenticated online opted-in workers may request non-authoritative compute tasks.");
    }
    private void info(HttpExchange ex) throws IOException {
        if(!"GET".equals(ex.getRequestMethod())){reject(ex,405,"GET required");return;}
        respond(ex,200,"{\"protocol\":\""+PROTOCOL+"\",\"app\":\"CH Compute\",\"algorithm\":\""+ALGORITHM+"\"}");
    }
    private void pair(HttpExchange ex) throws IOException {
        if(!isPost(ex))return;
        String ip=ex.getRemoteAddress().getAddress().getHostAddress();
        RateLimit limit=pairRate.computeIfAbsent(ip,k->new RateLimit());
        if(!limit.allow()){reject(ex,429,"too many pairing attempts");return;}
        String body=body(ex,2000);if(body==null)return;
        String code=readField(body,"code",20).toUpperCase(Locale.ROOT);
        PairCode pair=pendingPair.remove(code);
        if(pair==null||pair.expiry<System.currentTimeMillis()||!online.contains(pair.user)){
            reject(ex,403,"invalid or expired pairing code");return;
        }
        byte[] tokenBytes=new byte[32];random.nextBytes(tokenBytes);
        String token=Base64.getUrlEncoder().withoutPadding().encodeToString(tokenBytes);
        credentials.put(pair.user,hex(sha256(token.getBytes(StandardCharsets.UTF_8))));
        persistCredentials();
        respond(ex,200,"{\"token\":\""+token+"\"}");
    }
    private void getTask(HttpExchange ex) throws IOException {
        if(!isPost(ex))return;
        UUID user=authenticate(ex);if(user==null)return;
        String requestBody=body(ex,2000);
        if(requestBody==null)return;
        if(!requestBody.contains("\"protocol\":\""+PROTOCOL+"\"")){
            reject(ex,400,"unsupported client protocol");return;
        }
        Tile tile;
        synchronized(queueMutex){
            long now=System.currentTimeMillis();
            Iterator<Map.Entry<String,Lease>> it=active.entrySet().iterator();
            while(it.hasNext()){
                Lease l=it.next().getValue();
                if(l.expires<now){todo.offer(l.tile);it.remove();}
            }
            int userActive=0;
            for(Lease l : active.values()) if(l.user.equals(user)) userActive++;
            tile=userActive>=2?null:todo.poll();
            if(tile!=null)active.put(tile.id,new Lease(tile,user,now+180000L));
        }
        if(tile==null){respond(ex,200,"{\"task\":null}");return;}
        respond(ex,200,"{\"task\":{\"id\":\""+tile.id+"\",\"seed\":"+tile.seed+",\"base_x\":"+tile.baseX+",\"base_z\":"+tile.baseZ+",\"size\":128,\"algorithm\":\""+ALGORITHM+"\"}}");
    }
    private void postResult(HttpExchange ex) throws IOException {
        if(!isPost(ex))return;
        UUID user=authenticate(ex);if(user==null)return;
        String body=body(ex,40000);if(body==null)return;
        String id=readField(body,"id",100),str=readField(body,"data_base64",25000);
        if(id.isEmpty()||str.isEmpty()){reject(ex,400,"missing result fields");return;}
        byte[] heights;
        try{heights=Base64.getDecoder().decode(str);}catch(IllegalArgumentException err){reject(ex,400,"malformed base64");return;}
        if(heights.length!=TILE_SIZE*TILE_SIZE){reject(ex,400,"incorrect tile dimensions");return;}
        Lease lease;
        synchronized(queueMutex){lease=active.get(id);}
        if(lease==null||!lease.user.equals(user)||lease.expires<System.currentTimeMillis()){
            reject(ex,403,"task not leased to you or expired");return;
        }
        // Independently sample untrusted output. Never apply this result to an authoritative world.
        Random verify=new Random(lease.tile.seed^id.hashCode());
        for(int i=0;i<128;i++){
            int x=verify.nextInt(TILE_SIZE),z=verify.nextInt(TILE_SIZE);
            int expected=heightAt(lease.tile.seed,lease.tile.baseX+x,lease.tile.baseZ+z);
            if((heights[z*TILE_SIZE+x]&0xff)!=expected){
                reject(ex,422,"incorrect computation; tile rejected");return;
            }
        }
        // Durable auxiliary cache; never sent to WorldEdit/Minecraft chunks automatically.
        File folder=new File(getDataFolder(),"tiles");
        if(!folder.isDirectory()&&!folder.mkdirs()){reject(ex,500,"cache storage unavailable");return;}
        Path target=folder.toPath().resolve(id+".bin");
        try{Files.write(target,heights,StandardOpenOption.CREATE_NEW);}catch(FileAlreadyExistsException already){/* retried result */}catch(IOException err){reject(ex,500,"unable to write cache");return;}
        synchronized(queueMutex){active.remove(id);}
        completed.incrementAndGet();
        respond(ex,200,"{\"ok\":true}");
    }

    // Must match the Go application exactly. uint32 arithmetic is intentional.
    private static int grid(long seed,int gx,int gz){
        int h=(int)seed ^ (int)(seed>>>32) ^ gx*0x9E3779B1 ^ gz*0x85EBCA77;
        h^=h>>>16;h*=0x7FEB352D;h^=h>>>15;h*=0x846CA68B;h^=h>>>16;
        return Integer.remainderUnsigned(h,64);
    }
    static int heightAt(long seed,int x,int z){
        int gx=Math.floorDiv(x,16),gz=Math.floorDiv(z,16),wx=Math.floorMod(x,16),wz=Math.floorMod(z,16);
        int a=grid(seed,gx,gz),b=grid(seed,gx+1,gz),c=grid(seed,gx,gz+1),d=grid(seed,gx+1,gz+1);
        int y=(a*(16-wx)*(16-wz)+b*wx*(16-wz)+c*(16-wx)*wz+d*wx*wz+128)/256;
        return 48+y*3/4;
    }
    private UUID authenticate(HttpExchange ex)throws IOException{
        String auth=ex.getRequestHeaders().getFirst("Authorization");
        if(auth==null||!auth.startsWith("Bearer ")||auth.length()>180){reject(ex,401,"pairing required");return null;}
        String incoming=hex(sha256(auth.substring(7).getBytes(StandardCharsets.UTF_8)));
        byte[] bytes=hexToBytes(incoming);
        for(Map.Entry<UUID,String> e:credentials.entrySet()){
            if(MessageDigest.isEqual(bytes,hexToBytes(e.getValue()))){
                if(!online.contains(e.getKey())){reject(ex,403,"Minecraft account must be online to volunteer");return null;}
                return e.getKey();
            }
        }
        reject(ex,401,"invalid or revoked token");return null;
    }
    private boolean isPost(HttpExchange ex)throws IOException{
        if(!"POST".equals(ex.getRequestMethod())){reject(ex,405,"POST required");return false;}
        return true;
    }
    private String body(HttpExchange ex,int max)throws IOException{
        ByteArrayOutputStream buf=new ByteArrayOutputStream();byte[] block=new byte[2048];int count=0,n;
        try(InputStream in=ex.getRequestBody()){
            while((n=in.read(block))!=-1){count+=n;if(count>max){reject(ex,413,"request too large");return null;}buf.write(block,0,n);}
        }
        return buf.toString(StandardCharsets.UTF_8);
    }
    private static String readField(String data,String field,int max){
        // Intentionally narrow protocol: only ASCII IDs, Base64 and pairing tokens are accepted.
        Pattern p=Pattern.compile("\\\""+Pattern.quote(field)+"\\\"\\s*:\\s*\\\"([A-Za-z0-9_\\-+/=]{1,"+max+"})\\\"");
        Matcher m=p.matcher(data);return m.find()?m.group(1):"";
    }
    private void respond(HttpExchange ex,int status,String json)throws IOException{
        Headers h=ex.getResponseHeaders();
        h.set("Content-Type","application/json; charset=utf-8");h.set("Cache-Control","no-store");
        h.set("X-Content-Type-Options","nosniff");
        byte[] bytes=json.getBytes(StandardCharsets.UTF_8);
        ex.sendResponseHeaders(status,bytes.length);
        try(OutputStream out=ex.getResponseBody()){out.write(bytes);}
    }
    private void reject(HttpExchange ex,int status,String why)throws IOException{
        respond(ex,status,"{\"error\":\""+why+"\"}");
    }
    private void loadCredentials(){
        Path file=new File(getDataFolder(),"workers.properties").toPath();
        if(!Files.isRegularFile(file))return;
        Properties p=new Properties();
        try(InputStream in=Files.newInputStream(file)){p.load(in);for(String key:p.stringPropertyNames()){
            try{credentials.put(UUID.fromString(key),p.getProperty(key));}catch(IllegalArgumentException ignored){}
        }}catch(IOException e){getLogger().warning("Unable to load credentials: "+e.getMessage());}
    }
    private void persistCredentials(){
        synchronized(credentialsMutex){
            Properties p=new Properties();for(Map.Entry<UUID,String> e:credentials.entrySet())p.setProperty(e.getKey().toString(),e.getValue());
            Path file=new File(getDataFolder(),"workers.properties").toPath();Path tmp=file.resolveSibling(file.getFileName()+".tmp");
            try(OutputStream out=Files.newOutputStream(tmp)){p.store(out,"CH Compute SHA-256 token hashes - no plain tokens");}catch(IOException e){getLogger().warning("Could not persist worker authorizations: "+e.getMessage());return;}
            try{Files.move(tmp,file,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(IOException err){
                try{Files.move(tmp,file,StandardCopyOption.REPLACE_EXISTING);}catch(IOException second){getLogger().severe("Could not save worker authorizations: "+second.getMessage());}
            }
        }
    }
    private static byte[] sha256(byte[] value){try{return MessageDigest.getInstance("SHA-256").digest(value);}catch(NoSuchAlgorithmException e){throw new IllegalStateException(e);}}
    private static String hex(byte[] bytes){StringBuilder s=new StringBuilder(bytes.length*2);for(byte b:bytes)s.append(String.format(Locale.ROOT,"%02x",b&255));return s.toString();}
    private static byte[] hexToBytes(String v){try{return HexFormat.of().parseHex(v);}catch(IllegalArgumentException err){return new byte[0];}}
    private record PairCode(UUID user,long expiry){}
    private record Tile(String id,long seed,int baseX,int baseZ){}
    private record Lease(Tile tile,UUID user,long expires){}
    private static final class RateLimit {
        long since=System.currentTimeMillis();int attempts;
        synchronized boolean allow(){long now=System.currentTimeMillis();if(now-since>10*60*1000L){since=now;attempts=0;}return attempts++<10;}
    }
}
