# CH Compute 1.0 — Crafted Horizons

This is an experimental, opt-in auxiliary compute prototype for Paper 1.21.11, **not** a TPS, RAM, or tick-rate booster.

- `CHCompute-Windows.exe`: Windows 10/11 x64 companion app, opening a control panel on `http://127.0.0.1:18765` in your browser. No Java or Python installation needed.
- `CHCompute-Paper-1.21.jar`: Java 21+ Paper plugin that schedules non-authoritative 128x128 terrain-preview tiles and saves verified sample outputs.
- The app follows the Windows preferred display language; its main controls have translations for 60 languages. Some long safety text defaults to English in less common locales.
- Explicit opt-in, 1–2 CPU worker threads, approximate 5–80% CPU duty cycle, 64–2048MB soft memory limit; **disabled on every program start**. Browser closure pauses computing after ~90 seconds; use Exit to stop instantly.
- HTTPS with certificate SHA-256 pinning is required. Pair in Minecraft with `/chcompute pair` (10-minute single-use code); revoke with `/chcompute revoke`.
- The service never downloads executable tasks and never performs mining. No private files, screen contents, or browser history are read.

## Server installation

1. Back up the server and check CPU/RAM headroom.
2. In the Falix server panel open **Network → Ports → Add Port** to allocate a new TCP port, separate from Minecraft and voice chat. https://kb.falixnodes.net/falix/dashboard/networking/extra-port
3. Upload the plugin JAR into `/plugins/`.
4. Extract the **private** server ZIP into the server root so that `/plugins/CHCompute/config.yml` and `/plugins/CHCompute/server.p12` exist. **Never share the `.p12` or private `config.yml` with players.**
5. Update `https.port` to the exact allocated port and `https.public-address` to your `https://hostname:port`; set `https.enabled: true`.
6. Restart Paper. `/chcompute info` shows server certificate fingerprint; players copy the fingerprint from the in-game `/chcompute pair` command.
7. Test with one volunteer, then `/chcompute queue 5`. Tile outputs go to `/plugins/CHCompute/tiles/` and do not change any worlds.

## Safety

Volunteer calculations are auxiliary previews only. They do **not** add player RAM to Falix, share processor cache, compute Minecraft authoritative ticks, or improve TPS automatically. The server validates only a sample of each returned tile. Do not use volunteer results for economy, inventories, PvP, permissions or anti-cheat. No automatic installation or invisible client load. The unsigned Windows binary may trigger a reputation warning; inspect the source if needed instead of disabling security features.
