# Security design — CH Compute

- Server requires dedicated HTTPS/TLS endpoint. Public certificate SHA-256 is manually pinned by each desktop client. Connection fails on mismatch.
- Every player must explicitly obtain a 10-character, 10-minute, single-use code through Minecraft before pairing.
- Pairing attempts are rate-limited by IP in server memory. SHA-256 of a random 256-bit bearer token is stored on server, not its plaintext value. Users can revoke credentials in game.
- The server only accepts tasks from authenticated accounts currently online. Maximum two active tasks per volunteer. Leases expire after three minutes.
- The app refuses HTTP, remote redirects, and invalid certs. Local configuration web panel binds 127.0.0.1 only, requires a CSRF token for any settings change, and uses no cross-origin APIs.
- Every app launch starts with user-contributed processing OFF; no startup services or startup entries are created. Closing UI stops processing after a grace period; Exit shuts down immediately.
- Only fixed deterministic `ch-height-v1` 128x128 tile jobs are supported. No dynamic task code, scripts or plugin installation to volunteers.
- Result data is treated as untrusted. Server checks size and 128 pseudo-random samples, then caches only auxiliary result bytes. **Do not use as authoritative game output.**
- The private `server.p12` and server's `config.yml` must never be shared. Use only the public certificate fingerprint for client onboarding.
- The Go memory cap is a soft runtime GC limit; the app cannot guarantee a hardware-level 2 GiB cap or exclusive core ownership. For stronger enforcement use Windows Job Objects (future work).
- No remote security audit, external penetration test, live Falix TCP-port test or real-player throughput testing has been completed.
