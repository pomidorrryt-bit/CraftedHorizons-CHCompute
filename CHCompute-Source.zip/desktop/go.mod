module craftedhorizons/chcompute

go 1.23
