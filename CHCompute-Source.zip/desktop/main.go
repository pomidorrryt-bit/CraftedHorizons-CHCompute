package main

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"html/template"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"runtime"
	"strings"
	"sync/atomic"
	"time"
)

const page = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>CH Compute</title><style>
:root{color-scheme:dark;font-family:Inter,Segoe UI,Arial,sans-serif}body{margin:0;background:#0c1421;color:#eaf5ff}main{max-width:890px;margin:36px auto;padding:16px}header{display:flex;align-items:center;justify-content:space-between}h1{font-size:27px;margin:0}small,.muted{color:#94aabe}section{background:#17263b;border:1px solid #2a4258;border-radius:14px;margin:16px 0;padding:20px}h2{font-size:19px;margin-top:0}label{display:block;font-weight:600;margin-top:16px;margin-bottom:7px}input,select{background:#101f30;color:#eaf5ff;border:1px solid #496275;padding:12px;border-radius:8px;width:100%;box-sizing:border-box;font:inherit}input[type=checkbox]{width:auto;transform:scale(1.4);margin-right:10px}button{background:#20c5ad;border:0;border-radius:8px;padding:12px 18px;margin-top:15px;font-weight:bold;color:#051a22;cursor:pointer}button.alt{background:#335472;color:white;margin-left:8px}.cols{display:grid;grid-template-columns:1fr 1fr;gap:16px}.pill{border-radius:10px;background:#253a52;padding:10px;display:inline-block}.state{font-weight:bold;color:#27dbbd}.notice{padding:12px;background:#233b52;border-radius:8px;line-height:1.6}#message{min-height:30px;color:#ffcf7c}footer{padding:20px;text-align:center;color:#96aabc}code{word-break:break-all}a{color:#49ecd0}@media(max-width:600px){.cols{display:block}} </style></head><body><main><header><div><h1>⛏️ CH Compute</h1><small id="intro">Volunteer computing for Crafted Horizons</small></div><select id="language" style="width:220px"><option value="">Auto (Windows)</option></select></header>
<section><h2 id="consent_title"></h2><p class="notice" id="consent_info"></p><div class="pill"><span id="status_label"></span> <span class="state" id="status"></span></div><p><span id="done_label"></span>: <strong id="completed">0</strong> · <span id="running_label"></span>: <strong id="running">0</strong> · <span id="memory_live_label"></span>: <strong id="memory_live">0</strong> MB</p><p id="error" style="color:#ffa8a8"></p><label><input type="checkbox" id="enabled"><span id="enable_label"></span></label></section>
<section><h2 id="connect_title"></h2><div class="cols"><div><label id="server_label" for="server"></label><input id="server" type="url" placeholder="https://server.example:18083"></div><div><label id="cert_label" for="fingerprint"></label><input id="fingerprint" placeholder="SHA-256 (64 hex)"></div></div><button id="save" type="button"></button><label id="code_label" for="code"></label><input id="code" maxlength="10" placeholder="XXXXXXXXXX"><button id="pair" type="button"></button><p class="muted" id="pair_help"></p></section>
<section><h2 id="limits_title"></h2><div class="cols"><div><label id="threads_label" for="threads"></label><select id="threads"><option>1</option><option>2</option></select></div><div><label id="cpu_label" for="cpu"></label><input id="cpu" type="range" min="5" max="80" step="5"><div><span id="cpu_number"></span>%</div></div></div><label id="ram_label" for="ram"></label><select id="ram"><option value="64">64 MB</option><option value="128">128 MB</option><option value="256">256 MB</option><option value="512">512 MB</option><option value="1024">1024 MB</option><option value="1536">1536 MB</option><option value="2048">2048 MB</option></select><p class="muted" id="limit_help"></p><button id="save2" type="button"></button></section>
<section><h2 id="privacy_title"></h2><p id="privacy_body" class="notice"></p></section><div id="message"></div><button id="quit" class="alt" type="button">Exit application</button><footer>CH Compute · Open-source · Explicit opt-in · No mining or remote code execution</footer></main>
<script>
let state=null,dirty=false; const $=id=>document.getElementById(id);const csrf={{.CSRF}};
async function api(path,data){let r=await fetch('/api/'+path,{method:'POST',headers:{'Content-Type':'application/json','X-CHCompute-CSRF':csrf},body:JSON.stringify(data)});let j=await r.json();if(!r.ok)throw Error(j.error||r.statusText);return j}
async function refresh(keep){let r=await fetch('/api/state');let s=await r.json();state=s;const c=s.config,t=s.translations;
for(let [k,id] of Object.entries({intro:'intro',consent_title:'consent_title',consent_info:'consent_info',status:'status_label',completed:'done_label',running:'running_label',memory_live:'memory_live_label',enable:'enable_label',connect_title:'connect_title',server:'server_label',certificate:'cert_label',save:'save',pairing_code:'code_label',pair:'pair',pair_help:'pair_help',limits_title:'limits_title',threads:'threads_label',cpu:'cpu_label',ram:'ram_label',limit_help:'limit_help',privacy_title:'privacy_title',privacy_body:'privacy_body'})){if(t[k])$(id).textContent=t[k]}
$('save2').textContent=t.save||'Save'; $('status').textContent=t[s.stats.state]||s.stats.state;
$('completed').textContent=s.stats.completed;$('running').textContent=s.stats.running;$('memory_live').textContent=s.stats.resident_mb;$('error').textContent=s.stats.last_error||'';
if(!keep){$('server').value=c.server;$('fingerprint').value=c.fingerprint;$('enabled').checked=c.enabled;$('threads').value=c.threads;$('cpu').value=c.cpu_percent;$('ram').value=c.max_memory_mb;$('language').innerHTML='<option value="">Auto (Windows)</option>';for(let l of s.languages){let o=document.createElement('option');o.value=l.code;o.textContent=l.name;$('language').append(o)}$('language').value=c.language}
$('cpu_number').textContent=$('cpu').value;
}
function payload(){return {server:$('server').value.trim(),fingerprint:$('fingerprint').value.trim(),enabled:$('enabled').checked,threads:Number($('threads').value),max_memory_mb:Number($('ram').value),cpu_percent:Number($('cpu').value),language:$('language').value}}
async function save(){try{await api('configure',payload());$('message').textContent='✓';await refresh(false)}catch(e){$('message').textContent=e.message;await refresh(true)}}
$('save').onclick=save;$('save2').onclick=save;$('enabled').onchange=save;$('threads').onchange=save;$('cpu').oninput=()=>{$('cpu_number').textContent=$('cpu').value};$('cpu').onchange=save;$('ram').onchange=save;$('language').onchange=save;
$('quit').onclick=async()=>{if(confirm('Stop all computing and exit CH Compute?')){try{await api('quit',{})}catch(e){alert(e.message)}document.body.innerHTML='<main><h2>CH Compute stopped. You can close this tab.</h2></main>'}};
$('pair').onclick=async()=>{try{await save();let r=await api('pair',{code:$('code').value});$('message').textContent=r.message||'Paired';$('code').value='';await refresh(false)}catch(e){$('message').textContent=e.message}};
refresh(false).catch(e=>$('message').textContent=e.message);setInterval(()=>refresh(true).catch(()=>{}),4000);
</script></body></html>`

var tpl = template.Must(template.New("page").Parse(page))

type ErrorResult struct {
	Error string `json:"error"`
}

func jsonResponse(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
func main() {
	client := NewClient()
	client.StartWorkers()
	var lastSeen atomic.Int64
	lastSeen.Store(time.Now().Unix())
	csrfBytes := make([]byte, 20)
	if _, err := rand.Read(csrfBytes); err != nil {
		log.Fatal(err)
	}
	csrf := hex.EncodeToString(csrfBytes)
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Content-Security-Policy", "default-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'")
		_ = tpl.Execute(w, map[string]string{"CSRF": csrf})
	})
	mux.HandleFunc("/api/state", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "GET" {
			http.Error(w, "method not allowed", 405)
			return
		}
		lastSeen.Store(time.Now().Unix())
		cfg, stats := client.snapshot()
		visible := cfg
		visible.Token = ""
		lang := chooseLang(cfg.Language, systemLanguage())
		jsonResponse(w, 200, map[string]any{"config": visible, "stats": stats, "translations": locale(lang), "languages": languageList(), "detected_language": lang, "platform": runtime.GOOS, "app": "CH Compute"})
	})
	secure := func(w http.ResponseWriter, r *http.Request) bool {
		if r.Method != "POST" {
			jsonResponse(w, 405, ErrorResult{"POST required"})
			return false
		}
		if r.Header.Get("X-CHCompute-CSRF") != csrf {
			jsonResponse(w, 403, ErrorResult{"CSRF token missing"})
			return false
		}
		if r.Header.Get("Origin") != "" && !strings.HasPrefix(r.Header.Get("Origin"), "http://127.0.0.1:") {
			jsonResponse(w, 403, ErrorResult{"bad origin"})
			return false
		}
		r.Body = http.MaxBytesReader(w, r.Body, 8000)
		return true
	}
	mux.HandleFunc("/api/configure", func(w http.ResponseWriter, r *http.Request) {
		if !secure(w, r) {
			return
		}
		var v Config
		if err := json.NewDecoder(r.Body).Decode(&v); err != nil {
			jsonResponse(w, 400, ErrorResult{err.Error()})
			return
		}
		if err := client.update(v); err != nil {
			jsonResponse(w, 400, ErrorResult{err.Error()})
			return
		}
		jsonResponse(w, 200, map[string]string{"message": "saved"})
	})
	mux.HandleFunc("/api/pair", func(w http.ResponseWriter, r *http.Request) {
		if !secure(w, r) {
			return
		}
		var req struct {
			Code string `json:"code"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			jsonResponse(w, 400, ErrorResult{err.Error()})
			return
		}
		if err := client.Pair(req.Code); err != nil {
			jsonResponse(w, 400, ErrorResult{err.Error()})
			return
		}
		jsonResponse(w, 200, map[string]string{"message": "Connected. Enable volunteer mode to start."})
	})
	mux.HandleFunc("/api/stop", func(w http.ResponseWriter, r *http.Request) {
		if !secure(w, r) {
			return
		}
		client.stop()
		jsonResponse(w, 200, map[string]string{"message": "stopped"})
	})
	var server *http.Server
	mux.HandleFunc("/api/quit", func(w http.ResponseWriter, r *http.Request) {
		if !secure(w, r) {
			return
		}
		client.stop()
		jsonResponse(w, 200, map[string]string{"message": "exiting"})
		go func() {
			time.Sleep(200 * time.Millisecond)
			if client.cancel != nil {
				client.cancel()
			}
			if server != nil {
				ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
				defer cancel()
				_ = server.Shutdown(ctx)
			}
		}()
	})
	go func() {
		ticker := time.NewTicker(15 * time.Second)
		defer ticker.Stop()
		for range ticker.C {
			if time.Now().Unix()-lastSeen.Load() > 90 {
				client.stop()
			}
		}
	}()
	// Fixed loopback port avoids multiple simultaneous copies of the app.
	ln, err := net.Listen("tcp", "127.0.0.1:18765")
	address := "http://127.0.0.1:18765"
	if err != nil {
		// Already running: open its control panel, never start a second worker.
		resp, e := http.Get(address + "/api/state")
		if e == nil {
			var data map[string]any
			_ = json.NewDecoder(resp.Body).Decode(&data)
			_ = resp.Body.Close()
			if data["app"] == "CH Compute" {
				openBrowser(address)
				return
			}
		}
		log.Fatal("CH Compute could not open port 18765: ", err)
	}
	fmt.Println("CH Compute settings: " + address)
	go func() { time.Sleep(350 * time.Millisecond); openBrowser(address) }()
	server = &http.Server{Handler: mux, ReadHeaderTimeout: 5 * time.Second, IdleTimeout: 25 * time.Second}
	if err := server.Serve(ln); err != nil && err != http.ErrServerClosed {
		log.Fatal(err)
	}
}
func openBrowser(u string) {
	var cmd *exec.Cmd
	switch runtime.GOOS {
	case "windows":
		cmd = exec.Command("rundll32", "url.dll,FileProtocolHandler", u)
	case "darwin":
		cmd = exec.Command("open", u)
	default:
		cmd = exec.Command("xdg-open", u)
	}
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	_ = cmd.Start()
}

var _ = context.Background
