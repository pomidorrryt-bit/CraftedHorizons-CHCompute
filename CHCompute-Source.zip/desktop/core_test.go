package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
)

func TestHeightKnownVectors(t *testing.T) {
	cases := []struct {
		seed int64
		x, z int
		want byte
	}{{1, 0, 0, 48}, {1, -1, -1, 51}, {9223372036854775807, -1040, 309, 74}, {-65536, 127, 127, 69}}
	for _, c := range cases {
		if got := terrainHeight(c.seed, c.x, c.z); got != c.want {
			t.Fatalf("vector mismatch seed=%d x=%d z=%d: expected %d got %d", c.seed, c.x, c.z, c.want, got)
		}
	}
}
func TestTileIsBounded(t *testing.T) {
	data, err := computeHeightTile(context.Background(), Task{ID: "abc", Seed: 532, Size: 128, BaseX: -128, BaseZ: -128, Algorithm: taskAlgorithm}, 80)
	if err != nil {
		t.Fatal(err)
	}
	if len(data) != 16384 {
		t.Fatalf("want 16384 bytes, got %d", len(data))
	}
	for _, b := range data {
		if b < 48 || b > 96 {
			t.Fatalf("height out of safe bounds: %d", b)
		}
	}
}
func TestConfigSafety(t *testing.T) {
	s := defaultConfig()
	if s.Enabled {
		t.Fatal("should default to OFF")
	}
	s.Threads = 3
	if validateConfig(&s) == nil {
		t.Fatal("accepted more than two threads")
	}
	s.Threads = 1
	s.MaxMemoryMB = 3000
	if validateConfig(&s) == nil {
		t.Fatal("accepted >2GiB")
	}
	s.MaxMemoryMB = 256
	s.CPUPercent = 95
	if validateConfig(&s) == nil {
		t.Fatal("accepted >80 duty")
	}
	s.CPUPercent = 20
	s.Server = "http://example.com"
	if validateConfig(&s) == nil {
		t.Fatal("accepted cleartext HTTP")
	}
}
func TestRestartExplicitConsent(t *testing.T) {
	dir := t.TempDir()
	c := NewClient()
	c.path = filepath.Join(dir, "settings.json")
	c.cfg.Enabled = true
	if err := c.saveLocked(); err != nil {
		t.Fatal(err)
	}
	data, err := os.ReadFile(c.path)
	if err != nil {
		t.Fatal(err)
	}
	var v Config
	if err := json.Unmarshal(data, &v); err != nil {
		t.Fatal(err)
	}
	if v.Enabled {
		t.Fatal("persisted enabled, violating explicit start requirement")
	}
}
func TestPinnedTLSAndPair(t *testing.T) {
	server := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/v1/pair" {
			w.Header().Set("Content-Type", "application/json")
			_, _ = w.Write([]byte(`{"token":"abcdefghijklmnopqrstuvwxyz12345678"}`))
			return
		}
		http.NotFound(w, r)
	}))
	defer server.Close()
	hash := sha256.Sum256(server.Certificate().Raw)
	dir := t.TempDir()
	c := NewClient()
	c.path = filepath.Join(dir, "settings.json")
	c.cfg.Server = server.URL
	c.cfg.Fingerprint = hex.EncodeToString(hash[:])
	if err := c.Pair("ABCDEFGHJK"); err != nil {
		t.Fatal(err)
	}
	if c.cfg.Token == "" || c.cfg.Enabled {
		t.Fatalf("paired state invalid: token=%v enabled=%v", c.cfg.Token != "", c.cfg.Enabled)
	}
	c.cfg.Fingerprint = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	if err := c.Pair("ABCDEFGHJK"); err == nil {
		t.Fatal("accepted invalid certificate pin")
	}
}
func TestLanguageChoices(t *testing.T) {
	if len(translations) < 40 {
		t.Fatal("too few languages")
	}
	if chooseLang("", "pl-PL") != "pl" {
		t.Fatal("windows language not selected")
	}
	if chooseLang("", "zh-TW") != "zh-TW" {
		t.Fatal("traditional Chinese incorrect")
	}
	for code, m := range translations {
		if m["enable"] == "" || m["save"] == "" {
			t.Fatalf("missing core translation %s", code)
		}
	}
}
