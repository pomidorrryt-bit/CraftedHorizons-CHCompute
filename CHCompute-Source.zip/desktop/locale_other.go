//go:build !windows

package main

import (
	"os"
	"strings"
)

func systemLanguage() string {
	s := os.Getenv("LC_ALL")
	if s == "" {
		s = os.Getenv("LANG")
	}
	if s == "" {
		return "en"
	}
	return strings.ReplaceAll(strings.Split(s, ".")[0], "_", "-")
}
