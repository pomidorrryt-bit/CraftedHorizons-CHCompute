#!/bin/sh
set -eu
cd "$(dirname "$0")"
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -ldflags='-s -w -H windowsgui' -o CHCompute-Windows.exe
