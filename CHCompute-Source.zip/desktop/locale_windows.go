//go:build windows

package main

import (
	"strings"
	"syscall"
	"unsafe"
)

// Prefer Windows DISPLAY language (not just the regional formatting locale).
func systemLanguage() string {
	mui := syscall.NewLazyDLL("kernel32.dll").NewProc("GetUserPreferredUILanguages")
	var count, required uint32
	_, _, _ = mui.Call(8, uintptr(unsafe.Pointer(&count)), 0, uintptr(unsafe.Pointer(&required))) // MUI_LANGUAGE_NAME=8
	if required > 0 && required < 1024 {
		buf := make([]uint16, required)
		r, _, _ := mui.Call(8, uintptr(unsafe.Pointer(&count)), uintptr(unsafe.Pointer(&buf[0])), uintptr(unsafe.Pointer(&required)))
		if r != 0 {
			first := strings.TrimSpace(syscall.UTF16ToString(buf))
			if first != "" {
				return strings.ReplaceAll(first, "_", "-")
			}
		}
	}
	buf := make([]uint16, 85)
	p := syscall.NewLazyDLL("kernel32.dll").NewProc("GetUserDefaultLocaleName")
	r, _, _ := p.Call(uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
	if r > 0 {
		return strings.ReplaceAll(syscall.UTF16ToString(buf), "_", "-")
	}
	return "en"
}
