package main

import (
	"bytes"
	"context"
	"crypto/sha256"
	"crypto/tls"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"runtime"
	"runtime/debug"
	"strings"
	"sync"
	"time"
)

const protocolVersion = "chcompute/1"
const taskAlgorithm = "ch-height-v1"

type Config struct {
	Server      string `json:"server"`
	Fingerprint string `json:"fingerprint"`
	Token       string `json:"token"`
	Enabled     bool   `json:"enabled"`
	Threads     int    `json:"threads"`
	MaxMemoryMB int    `json:"max_memory_mb"`
	CPUPercent  int    `json:"cpu_percent"`
	Language    string `json:"language"`
}

type Stats struct {
	Completed   int64  `json:"completed"`
	Failed      int64  `json:"failed"`
	LastError   string `json:"last_error"`
	LastSuccess string `json:"last_success"`
	LastTask    string `json:"last_task"`
	ResidentMB  uint64 `json:"resident_mb"`
	Running     int    `json:"running"`
	State       string `json:"state"`
}

type Task struct {
	ID        string `json:"id"`
	Seed      int64  `json:"seed"`
	BaseX     int    `json:"base_x"`
	BaseZ     int    `json:"base_z"`
	Size      int    `json:"size"`
	Algorithm string `json:"algorithm"`
}

type PairReply struct {
	Token string `json:"token"`
}
type TaskReply struct {
	Task *Task `json:"task"`
}

type Client struct {
	mu     sync.RWMutex
	cfg    Config
	stats  Stats
	path   string
	cancel context.CancelFunc
}

func defaultConfig() Config {
	return Config{Threads: 1, MaxMemoryMB: 256, CPUPercent: 25, Language: "", Enabled: false}
}
func configPath() string {
	dir, err := os.UserConfigDir()
	if err != nil {
		dir = "."
	}
	return filepath.Join(dir, "CHCompute", "settings.json")
}
func NewClient() *Client {
	c := &Client{cfg: defaultConfig(), path: configPath(), stats: Stats{State: "off"}}
	raw, err := os.ReadFile(c.path)
	if err == nil {
		var cfg Config
		if json.Unmarshal(raw, &cfg) == nil && validateConfig(&cfg) == nil {
			c.cfg = cfg
		}
	}
	c.cfg.Enabled = false // Never consume resources automatically at startup.
	runtime.GOMAXPROCS(c.cfg.Threads)
	debug.SetMemoryLimit(int64(c.cfg.MaxMemoryMB) * 1024 * 1024)
	return c
}
func validateConfig(v *Config) error {
	if v.Threads < 1 || v.Threads > 2 {
		return errors.New("threads must be 1–2")
	}
	if v.MaxMemoryMB < 64 || v.MaxMemoryMB > 2048 {
		return errors.New("memory limit must be 64–2048 MB")
	}
	if v.CPUPercent < 5 || v.CPUPercent > 80 {
		return errors.New("CPU duty limit must be 5–80%")
	}
	if v.Server != "" {
		u, err := url.Parse(v.Server)
		if err != nil || u.Scheme != "https" || u.Host == "" || u.User != nil || (u.Path != "" && u.Path != "/") || u.RawQuery != "" || u.Fragment != "" {
			return errors.New("server must be an HTTPS address, e.g. https://hostname:port")
		}
		v.Server = strings.TrimRight(v.Server, "/")
	}
	v.Fingerprint = strings.ToLower(strings.ReplaceAll(strings.ReplaceAll(strings.TrimSpace(v.Fingerprint), ":", ""), " ", ""))
	if v.Fingerprint != "" {
		if len(v.Fingerprint) != 64 {
			return errors.New("certificate SHA-256 fingerprint must be 64 hex characters")
		}
		if _, err := hex.DecodeString(v.Fingerprint); err != nil {
			return errors.New("fingerprint is not hexadecimal")
		}
	}
	if v.Language != "" {
		if _, ok := translations[v.Language]; !ok {
			return errors.New("unknown language")
		}
	}
	if len(v.Token) > 150 {
		return errors.New("invalid token")
	}
	return nil
}
func (c *Client) saveLocked() error {
	// Never persist automatic activation. Each execution requires explicit consent.
	v := c.cfg
	v.Enabled = false
	raw, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		return err
	}
	if err = os.MkdirAll(filepath.Dir(c.path), 0700); err != nil {
		return err
	}
	temp := c.path + ".tmp"
	if err = os.WriteFile(temp, raw, 0600); err != nil {
		return err
	}
	return os.Rename(temp, c.path)
}
func (c *Client) snapshot() (Config, Stats) {
	c.mu.RLock()
	cfg, st := c.cfg, c.stats
	c.mu.RUnlock()
	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	st.ResidentMB = m.Sys / (1024 * 1024)
	if !cfg.Enabled {
		st.State = "off"
	} else if cfg.Token == "" {
		st.State = "not_paired"
	} else if st.Running > 0 {
		st.State = "working"
	} else {
		st.State = "idle"
	}
	return cfg, st
}
func (c *Client) update(v Config) error {
	if err := validateConfig(&v); err != nil {
		return err
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	// Token is server-issued. The web settings form cannot replace or clear it by accident.
	v.Token = c.cfg.Token
	// Changing server or certificate invalidates pairing.
	if v.Server != c.cfg.Server || v.Fingerprint != c.cfg.Fingerprint {
		v.Token = ""
		v.Enabled = false
	}
	if v.Enabled && (v.Server == "" || v.Fingerprint == "" || v.Token == "") {
		return errors.New("pair first using a Minecraft pairing code")
	}
	c.cfg = v
	runtime.GOMAXPROCS(v.Threads)
	debug.SetMemoryLimit(int64(v.MaxMemoryMB) * 1024 * 1024)
	return c.saveLocked()
}
func (c *Client) stop() {
	c.mu.Lock()
	c.cfg.Enabled = false
	_ = c.saveLocked()
	c.mu.Unlock()
}
func (c *Client) errorState(err error) {
	c.mu.Lock()
	c.stats.LastError = err.Error()
	c.stats.Failed++
	c.mu.Unlock()
}
func (c *Client) markDone(id string) {
	c.mu.Lock()
	c.stats.Completed++
	c.stats.LastSuccess = time.Now().Format(time.RFC3339)
	c.stats.LastTask = id
	c.stats.LastError = ""
	c.mu.Unlock()
}
func (c *Client) httpClient(cfg Config) (*http.Client, error) {
	if cfg.Server == "" || len(cfg.Fingerprint) != 64 {
		return nil, errors.New("provide HTTPS server and SHA-256 fingerprint")
	}
	expected, err := hex.DecodeString(cfg.Fingerprint)
	if err != nil {
		return nil, err
	}
	tr := &http.Transport{TLSClientConfig: &tls.Config{
		MinVersion: tls.VersionTLS12,
		// Pin verification below is mandatory and replaces standard CA validation for a local self-signed cert.
		InsecureSkipVerify: true,
		VerifyConnection: func(cs tls.ConnectionState) error {
			if len(cs.PeerCertificates) == 0 {
				return errors.New("server supplied no certificate")
			}
			actual := sha256.Sum256(cs.PeerCertificates[0].Raw)
			if !bytes.Equal(actual[:], expected) {
				return errors.New("TLS certificate fingerprint mismatch; connection refused")
			}
			return nil
		},
	}, MaxIdleConns: 2, IdleConnTimeout: 20 * time.Second, ResponseHeaderTimeout: 10 * time.Second, DisableCompression: true}
	return &http.Client{Transport: tr, Timeout: 18 * time.Second, CheckRedirect: func(req *http.Request, via []*http.Request) error { return http.ErrUseLastResponse }}, nil
}
func (c *Client) request(ctx context.Context, cfg Config, method, route string, body any, out any, token string) error {
	hc, err := c.httpClient(cfg)
	if err != nil {
		return err
	}
	defer hc.CloseIdleConnections()
	var rd io.Reader
	if body != nil {
		raw, err := json.Marshal(body)
		if err != nil {
			return err
		}
		if len(raw) > 100000 {
			return errors.New("request too large")
		}
		rd = bytes.NewReader(raw)
	}
	req, err := http.NewRequestWithContext(ctx, method, cfg.Server+route, rd)
	if err != nil {
		return err
	}
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("User-Agent", "CHCompute-Volunteer/1.0")
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	}
	resp, err := hc.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	raw, err := io.ReadAll(io.LimitReader(resp.Body, 140000))
	if err != nil {
		return err
	}
	if resp.StatusCode != http.StatusOK {
		var info struct {
			Error string `json:"error"`
		}
		_ = json.Unmarshal(raw, &info)
		if info.Error == "" {
			info.Error = resp.Status
		}
		return fmt.Errorf("server: %s", info.Error)
	}
	if out != nil {
		return json.Unmarshal(raw, out)
	}
	return nil
}
func (c *Client) Pair(code string) error {
	code = strings.ToUpper(strings.TrimSpace(code))
	if len(code) != 10 {
		return errors.New("pairing code must have 10 characters")
	}
	c.mu.RLock()
	cfg := c.cfg
	c.mu.RUnlock()
	var reply PairReply
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()
	if err := c.request(ctx, cfg, "POST", "/v1/pair", map[string]string{"code": code}, &reply, ""); err != nil {
		return err
	}
	if len(reply.Token) < 32 {
		return errors.New("server returned invalid token")
	}
	c.mu.Lock()
	c.cfg.Token = reply.Token
	c.cfg.Enabled = false
	err := c.saveLocked()
	c.mu.Unlock()
	return err
}
func (c *Client) worker(index int, ctx context.Context) {
	for {
		select {
		case <-ctx.Done():
			return
		default:
		}
		c.mu.RLock()
		cfg := c.cfg
		c.mu.RUnlock()
		if !cfg.Enabled || cfg.Token == "" || index >= cfg.Threads {
			wait(ctx, 2*time.Second)
			continue
		}
		var reply TaskReply
		rc, cancel := context.WithTimeout(ctx, 20*time.Second)
		err := c.request(rc, cfg, "POST", "/v1/task", map[string]string{"protocol": protocolVersion}, &reply, cfg.Token)
		cancel()
		if err != nil {
			c.errorState(err)
			wait(ctx, 8*time.Second)
			continue
		}
		if reply.Task == nil {
			wait(ctx, 3*time.Second)
			continue
		}
		task := reply.Task
		if task.Algorithm != taskAlgorithm || task.Size != 128 || task.BaseX < -30000000 || task.BaseX > 30000000 || task.BaseZ < -30000000 || task.BaseZ > 30000000 {
			c.errorState(errors.New("invalid or unsupported task"))
			wait(ctx, 3*time.Second)
			continue
		}
		c.mu.Lock()
		c.stats.Running++
		c.mu.Unlock()
		data, err := computeHeightTile(ctx, *task, cfg.CPUPercent)
		c.mu.Lock()
		c.stats.Running--
		c.mu.Unlock()
		if err != nil {
			wait(ctx, 1*time.Second)
			continue
		}
		result := map[string]string{"id": task.ID, "data_base64": base64.StdEncoding.EncodeToString(data)}
		rc, cancel = context.WithTimeout(ctx, 20*time.Second)
		err = c.request(rc, cfg, "POST", "/v1/result", result, nil, cfg.Token)
		cancel()
		if err != nil {
			c.errorState(err)
			wait(ctx, 8*time.Second)
			continue
		}
		c.markDone(task.ID)
	}
}
func (c *Client) StartWorkers() {
	ctx, cancel := context.WithCancel(context.Background())
	c.cancel = cancel
	for i := 0; i < 2; i++ {
		go c.worker(i, ctx)
	}
}
func wait(ctx context.Context, span time.Duration) {
	t := time.NewTimer(span)
	defer t.Stop()
	select {
	case <-t.C:
	case <-ctx.Done():
	}
}
func gridHash(seed int64, gx, gz int) uint32 {
	h := uint32(seed) ^ uint32(uint64(seed)>>32) ^ uint32(int32(gx))*0x9E3779B1 ^ uint32(int32(gz))*0x85EBCA77
	h ^= h >> 16
	h *= 0x7FEB352D
	h ^= h >> 15
	h *= 0x846CA68B
	h ^= h >> 16
	return h % 64
}
func floorDiv16(x int) int {
	if x >= 0 {
		return x / 16
	}
	return (x - 15) / 16
}
func floorMod16(x int) int { return x - floorDiv16(x)*16 }
func terrainHeight(seed int64, x, z int) byte {
	gx, gz := floorDiv16(x), floorDiv16(z)
	wx, wz := floorMod16(x), floorMod16(z)
	v00 := int(gridHash(seed, gx, gz))
	v10 := int(gridHash(seed, gx+1, gz))
	v01 := int(gridHash(seed, gx, gz+1))
	v11 := int(gridHash(seed, gx+1, gz+1))
	interpolated := (v00*(16-wx)*(16-wz) + v10*wx*(16-wz) + v01*(16-wx)*wz + v11*wx*wz + 128) / 256
	return byte(48 + interpolated*3/4)
}
func computeHeightTile(ctx context.Context, t Task, duty int) ([]byte, error) {
	data := make([]byte, t.Size*t.Size)
	for z := 0; z < t.Size; z += 8 {
		start := time.Now()
		for zz := z; zz < z+8 && zz < t.Size; zz++ {
			for x := 0; x < t.Size; x++ {
				data[zz*t.Size+x] = terrainHeight(t.Seed, t.BaseX+x, t.BaseZ+zz)
			}
		}
		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		default:
		}
		elapsed := time.Since(start)
		// Cooperative duty-cycle cap; hardware CPU utilization is approximate, not a hard OS quota.
		sleep := time.Duration(int64(elapsed) * (100 - int64(duty)) / int64(duty))
		if sleep < 500*time.Microsecond {
			sleep = 500 * time.Microsecond
		}
		tmr := time.NewTimer(sleep)
		select {
		case <-ctx.Done():
			tmr.Stop()
			return nil, ctx.Err()
		case <-tmr.C:
		}
	}
	return data, nil
}
